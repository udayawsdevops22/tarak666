import time
import csv
import requests

API_URL = "https://api.statuscake.com"
API_TOKEN = "cJA5DQ0mqfbtsV3IUHhL_N7YjBdEF2"


def make_get_request(endpoint, params=None):
    resp = requests.get(f"{API_URL}/{endpoint}", headers={"Authorization": f"Bearer {API_TOKEN}"}, params=params)
    if resp.status_code <= 299:
        return resp.json()
    # print(resp)
    return {}


def iterate_pages_for_test(page=1):
    tests = make_get_request('v1/uptime/', params={'page': page})
    # print(tests)
    for test in tests['data']:
        yield test
    if tests['metadata']['page_count'] > page:
        # print(page)
        for test in iterate_pages_for_test(page=page+1):
            yield test


def main():
    data_for_csv = []
    index = 0
    with open('status_cake.csv', 'w') as f:  # You will need 'wb' mode in Python 2.x
        w = None
        for test in iterate_pages_for_test():
            detailed_test = make_get_request(f'v1/uptime/{test["id"]}')
            # print(detailed_test)
            if 'data' in detailed_test:
                test.update(detailed_test['data'])
            if index == 0:
                w = csv.DictWriter(f, test.keys())
                w.writeheader()
            w.writerow(test)
            index = index + 1
            time.sleep(0.25)
        # print(test)

if __name__ == '__main__':
    main()

