import time
import csv
import requests
import datetime
import time, os
import subprocess
import smtplib
import socket
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email.utils import formatdate
COMMASPACE = ', '
from email import encoders
API_URL = "https://api.statuscake.com"
API_TOKEN = "cJA5DQ0mqfbtsV3IUHhL_N7YjBdEF2"

now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())
Mail_subject= 'Statuscake Report-'+ timestamp
Mail_text = 'Hi Team,\n\n This is full statuscake report generated using Api.\n\n Thanks,\n Webcc.'
#emails=[sys.argv[1]]
emails= 'tarakaramulu.hyderaboni@effem.com'
#To_mail='root@%s'%Hostname
To_mail='tarakaramulu.hyderaboni@effem.com'

#email function Do Not change
def send_mail(send_from, send_to, subject, text, files=[], server="uukm01.mars-inc.com"):
  #assert type(send_to)==list
  assert type(files)==list

  msg = MIMEMultipart()
  msg['From'] = send_from
  msg['To'] =  ", ".join(send_to)
  #msg['To'] = send_to
  msg['Date'] = formatdate(localtime=True)
  msg['Subject'] = subject
  msg.attach(MIMEText(text))
  filename='status_cake.csv.gz'
  attachment  =open(filename,'rb')

  part = MIMEBase('application','octet-stream')
  part.set_payload((attachment).read())
  encoders.encode_base64(part)
  part.add_header('Content-Disposition',"attachment; filename= "+filename)

  msg.attach(part)
  text = msg.as_string()
  smtp = smtplib.SMTP(server)
  smtp.sendmail(send_from, send_to, msg.as_string())
  smtp.close()
#email function end #
def make_get_request(endpoint, params=None):
    resp = requests.get(f"{API_URL}/{endpoint}", headers={"Authorization": f"Bearer {API_TOKEN}"}, params=params)
    if resp.status_code <= 299:
        return resp.json()
    # print(resp)
    return {}


def iterate_pages_for_test(page=1):
    tests = make_get_request('v1/uptime/', params={'page': page})
    # print(tests)
    for test in tests['data']:
        yield test
    if tests['metadata']['page_count'] > page:
        # print(page)
        for test in iterate_pages_for_test(page=page+1):
            yield test


def main():
    data_for_csv = []
    index = 0
    with open('status_cake.csv', 'w') as f:  # You will need 'wb' mode in Python 2.x
        w = None
        for test in iterate_pages_for_test():
            detailed_test = make_get_request(f'v1/uptime/{test["id"]}')
            # print(detailed_test)
            if 'data' in detailed_test:
                test.update(detailed_test['data'])
            if index == 0:
                w = csv.DictWriter(f, test.keys(),extrasaction='ignore')
                w.writeheader()
            w.writerow(test)
            index = index + 1
            time.sleep(0.30)
        #print(test)
    os.system('gzip status_cake.csv')
    time.sleep(30)
    send_mail(To_mail,emails,Mail_subject,Mail_text)

if __name__ == '__main__':
    main()

