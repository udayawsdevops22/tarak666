import requests
import json
import csv
 
# Set up Cloudflare API credentials
api_key = 'f16ccc6b739cc3082e744628ec142d7784053'
email = 'tarakaramulu.hyderaboni@effem.com'
api_base_url = 'https://api.cloudflare.com/client/v4'
headers = {
    'X-Auth-Key': api_key,
    'X-Auth-Email': email,
    'Content-Type': 'application/json'
}

zone_id = '5b9de91442467c2f6926c5714b444d94'
 
for zone in zones:
    # Get all DNS records for the zone
    response = requests.get('https://api.cloudflare.com/client/v4/zones/$zone/dns_records', headers=headers)
    data = json.loads(response.text)
    # Extract relevant information and write to CSV
    with open('dns_records.csv', 'w') as csvfile:
        csvwriter = csv.writer(csvfile)
        csvwriter.writerow(['Type', 'Name', 'Content', 'TTL', 'Proxied'])
        for record in data['result']:
            csvwriter.writerow([record['type'], record['name'], record['content'], record['ttl'], record['proxied']])
print "End of records"
