import requests
import csv

# Set up Cloudflare API credentials
api_key = 'f16ccc6b739cc3082e744628ec142d7784053'
email = 'tarakaramulu.hyderaboni@effem.com'
api_base_url = 'https://api.cloudflare.com/client/v4'
headers = {
    'X-Auth-Key': api_key,
    'X-Auth-Email': email,
    'Content-Type': 'application/json'
}

# Make API request to get zones
response = requests.get('https://api.cloudflare.com/client/v4/zones?per_page=750', headers=headers)
zones_data = response.json()

# Extract zone data
zones = zones_data.get('result', [])
zone_data_list = [(zone['name'], zone['id']) for zone in zones]

# Write zone data to CSV file
with open('zones.csv', 'w') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerow(['Zone Name', 'Zone ID'])
    writer.writerows(zone_data_list)

print('Zones and Zone IDs exported to zones_12092023.csv')
