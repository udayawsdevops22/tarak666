for z in `cat zones_full`; do 
  echo $z; 
   curl -s -H "X-Auth-Email: tarakaramulu.hyderaboni@effem.com" -H "X-Auth-Key: f16ccc6b739cc3082e744628ec142d7784053"  GET "https://api.cloudflare.com/client/v4/zones/"$z"/dns_records" | jq -r '.result[] | [.name, .type, .content] | @csv' >> DNS_details.csv
done
