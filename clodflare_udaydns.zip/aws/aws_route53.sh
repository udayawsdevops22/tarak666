for z in `cat zones_full`; do 
  echo $z; 
  aws route53 list-resource-record-sets --hosted-zone-id "/hostedzone/$z" | jq -r '.ResourceRecordSets[] | [.Name, .Type, (.ResourceRecords[]? | .Value), .AliasTarget.DNSName?] | @csv' >>  route53_kz.csv; 
done
