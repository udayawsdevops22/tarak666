#!/usr/bin/python
import os
import re
import subprocess
import datetime
import time
import smtplib
import socket
#Step1 #Zone Creation
#os.system(''' curl -X POST "https://api.cloudflare.com/client/v4/zones" -H "X-Auth-Email: web.tcc.team@effem.com" -H "X-Auth-Key: 49d1601884ee38d4099ab58c55275e609acaa" -H "Content-Type: application/json" --data '{"name":"test1.mars-inc.com","account":{"id":"e6f519836e79539e099dff199d641d02"}, "jump_start":true,"type":"partial"}'|jq ''')

# Step 2 Get new zone ID
status, output = subprocess.getstatusoutput(
        ''' curl -X GET "https://api.cloudflare.com/client/v4/zones?name=test1.mars-inc.com" -H "X-Auth-Email: web.tcc.team@effem.com" -H "X-Auth-Key: 49d1601884ee38d4099ab58c55275e609acaa"  -H "Content-Type: application/json"  | jq -r | grep '''"id"''' |  head -n1 |awk '{print $2;}' | sed 's/\,/ \ /g' | sed 's/\"//g' ''')
 

#Zoneid= os.system(''' curl -X GET "https://api.cloudflare.com/client/v4/zones?name=test1.mars-inc.com" -H "X-Auth-Email: web.tcc.team@effem.com" -H "X-Auth-Key: 49d1601884ee38d4099ab58c55275e609acaa"  -H "Content-Type: application/json"  | jq -r | grep '''"id"''' |  head -n1 |awk '{print $2;}' | sed 's/\,/ \ /g' | sed 's/\"//g' ''') 
print Zoneid
#Step3  Change plan to enterprise Paln
#ChangePlan= ((''' curl -X PATCH https://api.cloudflare.com/client/v4/zones/%s -H 'Content-Type: application/json' -H 'X-Auth-Key: 49d1601884ee38d4099ab58c55275e609acaa' -H 'X-Auth-Email:web.tcc.team@effem.com' -d '{"plan":{"id":"94f3b7b768b0458b56d2cac4fe5ec0f9"}}'|jq ''') %(Zone_id))
#print Zone_id
#print ChangePlan