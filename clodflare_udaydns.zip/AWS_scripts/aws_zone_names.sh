for z in `cat zones`; do
  echo $z ',' aws route53 list-hosted-zones-by-name --dns-name $z  --max-items 1 | jq '.[] | .[] | .Id' | sed '
s!/hostedzone/!!' | sed 's/"//g'
done
