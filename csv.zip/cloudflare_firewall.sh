#!/bin/bash
read -p "Enter Domin name: " Domain_name
#read -p "Enter IP address: " IP
read -p "Continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1
API_Email="web.tcc.team@effem.com"
API_KEY="49d1601884ee38d4099ab58c55275e609acaa"
zoneid=$(curl -X GET "https://api.cloudflare.com/client/v4/zones?name=$Domain_name" -H "X-Auth-Email: $API_Email" -H "X-Auth-Key: $API_KEY" -H "Content-Type:application/json" | grep -Po '"id": *\K"[^"]*"' | head -n 1 | sed 's/"//g')
echo $zoneid
EXP=$(curl -X POST "https://api.cloudflare.com/client/v4/zones/$zoneid/filters" -H "X-Auth-Email: $API_Email" -H "X-Auth-Key: $API_KEY" -H "Content-Type: application/json" -d '[  {   "expression": "ip.src eq 127.0.0.1"   }]' | grep -Po '"id": *\K"[^"]*"')
echo $EXP
curl -X POST "https://api.cloudflare.com/client/v4/zones/$zoneid/firewall/rules" -H "X-Auth-Email: $API_Email" -H "X-Auth-Key: $API_KEY" -H "Content-Type: application/json" -d '[  { "filter": { "id": '''$EXP''' }, "action": "allow", "description": "Do not challenge login from office" }]'
