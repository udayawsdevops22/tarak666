import CloudFlare, sys
class recursion_depth:
    def __init__(self, limit):
        self.limit = limit
        self.default_limit = sys.getrecursionlimit()
cf = CloudFlare.CloudFlare()
zones = cf.zones.get()

for zone in zones:
    for record in cf.zones.dns_records.get(zone['id'], params={'per_page':100}):
        print record['name'] + ',' + record['type'] + ',' + record['content']
