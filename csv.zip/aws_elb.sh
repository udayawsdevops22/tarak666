#aws elbv2 describe-target-groups | jq -r '.TargetGroups | .[] | [.TargetGroupArn, .TargetGroupName] | join(",")' > output.csv
#sleep 30 

while IFS=, read -r field1 field2
do
	if [[ aws elbv2 describe-target-health --target-group-arn $field1 | jq -r '.TargetHealthDescriptions[].TargetHealth[]'] -ne "healthy"] 
        then 
	echo $field2
	( aws elbv2 describe-target-health --target-group-arn $field1 | jq -r '.TargetHealthDescriptions[].TargetHealth[]','.TargetHealthDescriptions[].Target.AvailabilityZone' )
fi
done < output.csv 
