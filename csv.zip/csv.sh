#! /bin/bash
while IFS="," read -r description action Expression 
do
  echo $Expression
done < input1.csv 
