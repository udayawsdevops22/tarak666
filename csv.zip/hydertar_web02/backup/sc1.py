import csv
import requests, json
import os
URL = 'https://app.statuscake.com/API/Tests/Update'
headers = {'content-type': 'application/json', 'Accept-Charset': 'UTF-8',
            'API': 'n8z47hIIErcEcUnXtivj', 'Username':'WebCCHosting'
            }
            #provide API KEY AND USERNAME
            # Make sure all the column names same as in Field Value 
            # https://www.statuscake.com/api/Tests/Updating%20Inserting%20and%20Deleting%20Tests.md
            # bold field values are required columns.
#wb = open_workbook('WEBSITE.xlsx')

with open('WEBSITEa.csv') as csvfile:

    reader = csv.DictReader(csvfile)
    for request_data in reader:
	print request_data
	print request_data[3]
	print request_data[1]
	print request_data[2]

	Outeput = os.system('cat WEBSITEa.csv')
	print Outeput
        #r = requests.put(URL, data=json.dumps(request_data), headers=headers)
        #print "Status code is: %s"%r.status_code
        #print r.text
        #print r.json
        
