#!/usr/bin/python
# import the MySQLdb and sys modules
import MySQLdb
import os
import csv 
import sys 
import time
import datetime
from datetime import date, timedelta
import smtplib
bodytext = " "
 
# Mysql database connection 
f = open("list.txt", "r");
for lines in f:
    list1 = lines.replace("\n", "")
    connection = MySQLdb.connect (host = list1, user = "reports", passwd = "Mars123$", db = "psa" )
    cursor = connection.cursor ()
    cursor.execute ("select name from domains;")
    groupids = cursor.fetchall ()
    cursor.execute ("select name, status from domains WHERE status != 0;")
    status = cursor.fetchall ()
    bodytext += str(status).replace("('", "").replace(")", "").replace("(", "")
    #print groupids
    output1 = str(groupids).replace("('", "").replace(")","\n").replace("'" ,"").replace("," ,"")
    #output1 = str(groupids)
    output2 = "HOST:" +str(list1)+ "\n"+"Totalsites:" + str(cursor.rowcount) + "\n" + "Sites List:" +str(output1)
    #output2 = str(output1)
    bodytext += output2 + ","
    #bodytext += groupids
    #output = getDb()
    #print bodytext
    #for lines in list1:
    #print output2 
    print bodytext
    #temp = open("temp.csv","w")
    #c1 = csv.writer((temp), delimiter=' ', quotechar='|', quoting=csv.QUOTE_MINIMAL)
    #c1 = csv.writer(temp)

	#c1.writeheader()
        #c1.writerow( ('Title 1', 'Title 2', 'Title 3') )
    #c1.writerow(output2)
