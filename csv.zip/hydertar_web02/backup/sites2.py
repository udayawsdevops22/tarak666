#!/usr/bin/python
# import the MySQLdb and sys modules
import MySQLdb
import os
import csv 
import sys 
import time
import datetime
from datetime import date, timedelta
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders
 
# Date 
todaydate = datetime.date.today()
weekbackdate = datetime.date.today()-timedelta(days=7)
todaydate1 = datetime.date.today()+timedelta(days=1)
#weekbackdate = '2014-08-22'
#todaydate1 = '2014-08-30'
#todaydate = '2014-08-29'
# Mail function 
#f = open("list.txt", "r");
#for lines in f:
#    print lines
bodytext = " "
def send_mail(send_from, send_to, subject, text, files=[], server="uukmx01.mars-inc.com"):
  assert type(send_to)==list
  assert type(files)==list
 
  msg = MIMEMultipart()
  msg['From'] = send_from
  msg['To'] = COMMASPACE.join(send_to)
  msg['Date'] = formatdate(localtime=True)
  msg['Subject'] = subject
 
  msg.attach( MIMEText(text, 'html') )
 
  for f in files:
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(f,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(f))
    msg.attach(part)
 
  smtp = smtplib.SMTP(server)
  smtp.sendmail(send_from, send_to, msg.as_string())
  smtp.close()
bodytext = " "
 
def Dictfetchall(cursor):
    """Returns all rows from a cursor as a dict."""
    desc = cursor.description
    return [dict(zip([col[0] for col in desc], row))
         for row in cursor.fetchall()
        ]
# Mysql database connection 
def getDb():
    f = open("list.txt", "r");
    for lines in f:
        list1 = lines.replace("\n", "")
        connection = MySQLdb.connect (host = list1, user = "reports", passwd = "Mars123$", db = "psa" )
	 # prepare a cursor object using cursor() method
        cursor = connection.cursor ()
	# execute the SQL query using execute() method.
        cursor.execute ("select name from domains;")
	# fetch all of the rows from the query
        groupids = cursor.fetchall ()
        #bodytext = list1
        #print groupids
	output1 = str(groupids).replace("('", "").replace(")","\n").replace("'" ,"").replace("," ,"")
	#output1 = str(groupids)
	#return output1
#	c = csv.writer(open("temp.csv","wb"))
#	c.writecolumn(output1)
	#bodytext += "HostName:"
	#bodytext += list1	
	output2 = "HOST:" +str(list1)+ "\n"+"Totalsites:" + str(cursor.rowcount) + "\n" + "Sites List:\n" +str(output1)
	
#c = open("temp.csv","wb")
	#c1 = csv.writer(c, quotechar=',') 
        #c1.writerow(output2)
	print output2
output = getDb()
#print bodytext
email = "tarakaramulu.hyderaboni@effem.com","srinivasarao.sabbana@effem.com"
#send_mail("tarakaramulu.hyderaboni@effem.com,srinivasarao.sabbana@effem.com", "tarakaramulu.hyderaboni@effem.com,srinivasarao.sabbana@effem.com","Sites List",bodytext)
#send_mail("tarakaramulu.hyderaboni@effem.com", email,"Permissions",bodytext)
