#!/usr/bin/python
# import the MySQLdb and sys modules
import MySQLdb
import os
import csv
import sys
import time
import datetime
from datetime import date, timedelta
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders

# Date
todaydate = datetime.date.today()
weekbackdate = datetime.date.today()-timedelta(days=7)
todaydate1 = datetime.date.today()+timedelta(days=1)
#weekbackdate = '2014-08-22'
#todaydate1 = '2014-08-30'
#todaydate = '2014-08-29'
# Mail function
bodytext = " "
def Dictfetchall(cursor):
    """Returns all rows from a cursor as a dict."""
    desc = cursor.description
    return [dict(zip([col[0] for col in desc], row))
         for row in cursor.fetchall()
        ]
# Mysql database connection
f = open("list.txt", "r");
output_dict = {}
for lines in f:
    list1 = lines.replace("\n", "")
    connection = MySQLdb.connect (host = list1, user = "reports", passwd = "Mars123$", db = "psa" )
    # prepare a cursor object using cursor() method
    cursor = connection.cursor ()
    # execute the SQL query using execute() method.
    cursor.execute ("select name from domains;")
    # fetch all of the rows from the query
    #groupids = cursor.fetchall ()
    groupids = [item[0] for item in cursor.fetchall()]
    # execute the SQL query for stop state.
    #cursor.execute ("select name, status from domains WHERE status != 0;")
    #status = cursor.fetchall ()
    #bodytext += str(status).replace("('", "").replace(")", "").replace("(", "")
    #print groupids
    output1 = str(groupids).replace("('", "").replace(")","\n").replace("'" ,"").replace("," ,"")
    output2 = str(output1)
    output_dict[list1] = ["Total Active sites: %s"%cursor.rowcount]+groupids 
    connection.close()
with open("webhost_records.csv", "wb") as outfile:
   writer = csv.writer(outfile)
   writer.writerow(output_dict.keys())
   #writer.writerows(zip(*output_dict.values()))
   writer.writerows(map(None,*output_dict.values()))


