#!/usr/bin/env python
# Copyright 1999-2016. Parallels IP Holdings GmbH. All Rights Reserved.

import os
from plesk_api_client import PleskApiClient

host = os.getenv('REMOTE_HOST')
login = os.getenv('REMOTE_LOGIN', 'admin')
password = os.getenv('REMOTE_PASSWORD')

client = PleskApiClient(host)
client.set_credentials(login, password)

request = """
<?xml version="1.0" encoding="UTF-8"?>
<packet version="12.5.0.0">
<server>
<set>
<result>
<status>ok</status>
</result>
</set>
</server>
</packet>
"""

response = client.request(request)
print response
