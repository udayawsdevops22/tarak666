#!/usr/bin/python
import os
import re
import datetime
import time
import smtplib
import socket
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())
Mail_subject= 'Capicity management weekly Report on '+ Hostname +' '+ timestamp
emails= 'tarakaramulu.hyderaboni@effem.com','vinod.kumar.gunnam@effem.com'
#email function Do Not change
def send_mail(send_from, send_to, subject, text, files=[], server="dpuk-pl-uukmx01.mars-inc.com"):
  #assert type(send_to)==list
  #assert type(files)==list

  msg = MIMEMultipart()
  msg['From'] = send_from
  msg['To'] = COMMASPACE.join(send_to)
  msg['Date'] = formatdate(localtime=True)
  msg['Subject'] = subject

  msg.attach( MIMEText(text) )

  for f in files:
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(f,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(f))
    msg.attach(part)

  smtp = smtplib.SMTP(server)
  smtp.sendmail(send_from, send_to, msg.as_string())
  smtp.close()

bodytext = " "
bodytext+="\n Hello Team,\n Below are the list of sites and Total active sites count, Please update capacity management Sheet\n\n"
bodytext+="\nList of active Sites\n----------------------\n" 
bodytext_suspend = " "
bodytext_suspend+= "\nList of Suspended sites\n-------------------\n"
#Command to find all domain in server
os.system(' sudo plesk bin site --list > site_list.txt')
#Domains Count
with open('site_list.txt') as Totalcount:
    Domains_Count = sum(1 for _ in Totalcount)
#Skip the empty lines from file
with open("site_list.txt", "r") as f:
    names_list = [line.strip() for line in f if line.strip()]
#find the suspend site from total Domains
for sites in names_list:
    bodytext+="\n"
    #print sites
    Activesites = os.system("sudo plesk bin site -i %s |grep suspended" %sites)
    #print Activesites
    if Activesites == 256:
       bodytext+=sites+'\n' 
    else:
       bodytext_suspend+=sites+'\n'
#Check the count of suspend sites
text_file = open('output.txt', 'w')
text_file.write(bodytext_suspend)
text_file.close()
with open('output.txt') as Totalcount1:
    suspend_count = sum(1 for _ in Totalcount1)
#Total count - suspend sount
Active_domains = Domains_Count - suspend_count + 3
Total_domanins= "\n===========\nDomains:"+ str(Domains_Count)
Total_Active_domains= "\n============================\nTotal Active domains Count:" + str(Active_domains)
Mail_text = bodytext + bodytext_suspend + Total_domanins + Total_Active_domains
send_mail("tarakaramulu.hyderaboni@effem.com", emails,Mail_subject,Mail_text)
os.remove('site_list.txt')
os.remove('output.txt')

