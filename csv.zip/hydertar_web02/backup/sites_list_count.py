import MySQLdb as dbapi
import sys
import csv

dbServer='dpuk-vl-web01'
dbPass='Mars123$'
dbSchema='psa'
dbUser='reports'

dbQuery='select name,status from domains;'

#db=dbapi.connect(host=dbServer,user=dbUser,passwd=dbPass)
db = dbapi.connect(host="dpuk-vl-web01",    # your host, usually localhost
                     user="reports",         # your username
                     passwd="Mars123$",  # your password
                     db="psa")
cur=db.cursor()
cur.execute(dbQuery)
data = cur.fetchall()
list = []

for row in data :
  value = str(row)
  print value 
  list.append(value)    
  file = open('temp.csv', 'wb')
  data = csv.writer(file)
  data.writerow(list)

cur.close()
db.close()
file.close()
