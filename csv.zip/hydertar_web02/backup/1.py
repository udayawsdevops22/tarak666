import csv
import os 
import sys #used for passing in the argument
API = "n8z47hIIErcEcUnXtivj"
Username = "WebCCHosting"
Url = "https://app.statuscake.com/API/Tests/Update"
file_name = "WEBSITEa.csv" #filename is argument 1
with open(file_name, 'rU') as f:  #opens PW file
    reader = csv.reader(f)
    data = list(list(rec) for rec in csv.reader(f, delimiter=',')) #reads csv into a list of lists

    for row in data:
        #print row[0] #this alone will print all the computer names
        print row[1]
        print row[3]
        CMD = os.system ("'curl -H '"'API:'API'" -H "Username:'Username'" -d "TestID='row[0]'&TestTags='Server1'" -X PUT' Url")
#	CMD = os.system ('cat WEBSITEa.csv')
        print CMD

