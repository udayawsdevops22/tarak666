#!/usr/bin/python
# import the MySQLdb and sys modules
import MySQLdb
import os
import csv 
import sys 
import time
import datetime
from datetime import date, timedelta
import smtplib
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import Encoders
 
# Date 
todaydate = datetime.date.today()
weekbackdate = datetime.date.today()-timedelta(days=7)
todaydate1 = datetime.date.today()+timedelta(days=1)
#weekbackdate = '2014-08-22'
#todaydate1 = '2014-08-30'
#todaydate = '2014-08-29'
# Mail function 
bodytext = " "
def send_mail(send_from, send_to, subject, text, files=[], server="localhost"):
  assert type(send_to)==list
  assert type(files)==list
 
  msg = MIMEMultipart()
  msg['From'] = send_from
  msg['To'] = COMMASPACE.join(send_to)
  msg['Date'] = formatdate(localtime=True)
  msg['Subject'] = subject
 
  msg.attach( MIMEText(text, 'html') )
 
  for f in files:
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(f,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(f))
    msg.attach(part)
 
  smtp = smtplib.SMTP(server)
  smtp.sendmail(send_from, send_to, msg.as_string())
  smtp.close()
bodytext = " "
 
def Dictfetchall(cursor):
    """Returns all rows from a cursor as a dict."""
    desc = cursor.description
    return [dict(zip([col[0] for col in desc], row))
         for row in cursor.fetchall()
        ]
# Mysql database connection 
f = open("list.txt", "r");
for lines in f:
    list1 = lines.replace("\n", "")
    connection = MySQLdb.connect (host = list1, user = "reports", passwd = "Mars123$", db = "psa" )
    # prepare a cursor object using cursor() method
    cursor = connection.cursor ()
    # execute the SQL query using execute() method.
    cursor.execute ("select name from domains;")
    # fetch all of the rows from the query
    groupids = cursor.fetchall ()
    # execute the SQL query for stop state. 
    #cursor.execute ("select name, status from domains WHERE status != 0;")
    #status = cursor.fetchall ()
    #bodytext += str(status).replace("('", "").replace(")", "").replace("(", "")
    #print groupids
    output1 = str(groupids).replace("('", "").replace(")","\n").replace("'" ,"").replace("," ,"")
    #output1 = str(groupids)
    #output2 = "HOST:" +str(list1)+ "\n"+"Totalsites:" + str(cursor.rowcount) + "\n" + "Sites List:" +str(output1)
    output2 = str(output1)
    #bodytext += output2 + ","
    #bodytext += groupids
#output = getDb()
    #print bodytext
    for lines in groupids:
        bodytext += str(lines)
    #print lines + "1"
#    temp = open("temp.csv","wb")
#    for row in groupids:
#        print (row)
        #c1 = csv.writer((temp),dialect=csv.excel,delimiter='\t')
#        c1 = csv.writer(temp)
        #c1.writerow( ('Title 1', 'Title 2', 'Title 3') )
 #       c1.writerow(row)
#c1.writerow('\n')
print bodytext
temp = open("temp.csv","wb")
c1 = csv.writer((temp),dialect=csv.excel,delimiter='\t')
c1 = csv.writer(temp)
        #c1.writerow( ('Title 1', 'Title 2', 'Title 3') )
c1.writerow(bodytext)
