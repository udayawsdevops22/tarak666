import csv
import os, sys
import subprocess
API_KEY = 'n8z47hIIErcEcUnXtivj'
USERNAME = 'WebCCHosting'

            #provide API KEY AND USERNAME
            # Make sure all the column names same as in Field Value
            # https://www.statuscake.com/api/Tests/Updating%20Inserting%20and%20Deleting%20Tests.md
            # bold field values are required columns.

with open('WEBSITEa.csv') as csvfile:

    reader = csv.DictReader(csvfile)
    #tableHeader = next(reader)
    #wb = open_workbook('WEBSITEa.csv')

for s in reader:
    #print 'Sheet:',s.name
    for row in range(1, s.nrows):
        col_names = s.row(0)
        col_value = []
        request_data = {}
        for name, col in zip(col_names, range(s.ncols)):
            value  = (s.cell(row,col).value)
            try : value = str(int(value))
            except : pass
            if value:
                request_data[name.value] = value
            col_value.append((name.value, value))
        r = requests.put(URL, data=json.dumps(request_data), headers=headers)
        print "Status code is: %s"%r.status_code
        print r.text
        print r.json

