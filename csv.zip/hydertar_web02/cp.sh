#/bin/sh
n=$1
sudo plesk bin site --list > list.txt
cat list.txt | while read LINE
do
comm=`sudo plesk bin site -i $LINE | grep OK | wc -l`
#sum=$(expr "$comm" + "$comm")
sum=0
for i in $comm ; do
    ## redefine variable 'sum' after each iteration of for-loop
    sum=`expr $sum + $i`
done
echo $sum
done
