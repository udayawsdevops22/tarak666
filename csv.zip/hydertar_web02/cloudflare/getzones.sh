for zone in `aws route53 list-hosted-zones | jq -r '.HostedZones[].Id'`; do 
  aws route53 list-resource-record-sets --hosted-zone-id $zone --query "ResourceRecordSets[?Type == 'CNAME']" |\
  jq -r '.[].Name' |\
    while read record; do \
      if [[ $(host $record | grep 'not found') ]]; then \
        echo $record;
      fi;
    done;
done
