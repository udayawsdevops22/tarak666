for z in `cat zones_full`; do 
  echo $z; 
  curl -s -H "X-Auth-Email: fahad.javaid@effem.com" -H "X-Auth-Key: 9170e69d2ea70069f0063652db9f88e492609"  GET "https://api.cloudflare.com/client/v4/zones/$z/dns_records/export" >> DNS.txt; 
done
