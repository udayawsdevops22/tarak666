import os
import sys
import csv
import json
import datetime
import time
import subprocess
import smtplib
import socket
response_json = "cloudflare_res.json"
API_KEY = "AUHsiustZEn7MjsPvPrhkns-6lw6PFRWdqNZ4ijV"
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())
def main():
    f = csv.writer(open("cloudflar_report_Zones.csv", "w"))

    status, output = subprocess.getstatusoutput(
        "curl -H \"Authorization: Bearer %s\" -X GET https://api.cloudflare.com/client/v4/zones?per_page=150 -H Content-Type:application/json > %s"%(API_KEY, response_json)
    )

    json_file = open(response_json,"r")

    json_decoded = json.load(json_file)
    col_names = json_decoded['result'][0].keys()
    # Write CSV Header, If you dont need that, remove this line
    f.writerow(col_names)

    print(json_decoded)
    print("Start at {}".format(datetime.datetime.now()))
    for row in json_decoded['result']:

        row_item = []

        for col in col_names:
            try:
                row_item.append(row[col])
            except KeyError:
                row_item.append('')
        f.writerow(row_item)
    #print "Total done for {} is {}, finished at {}secs".format(state, len(x["data"]), (time.time()-start_time))

  
if __name__ == "__main__":
    main()
