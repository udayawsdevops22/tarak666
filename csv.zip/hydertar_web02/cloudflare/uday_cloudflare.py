import sys
import csv
import json
import commands
import datetime
import time
import subprocess
import smtplib
import socket
response_json = "cloudflare_res.json"
API_KEY = "AUHsiustZEn7MjsPvPrhkns-6lw6PFRWdqNZ4ijV"
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())
def main():
    status, output = commands.getstatusoutput("curl -H \"X-Auth-Email: web.tcc.team@effem.com"  -H \ "X-Auth-Key: 49d1601
884ee38d4099ab58c55275e609acaa"\" -X GET http
s://api.cloudflare.com/client/v4/zones?name=test1.mars-inc.com -H Content-Type:application/json > %s"%(response_js
on)
        )

        json_file = open(response_json,"r")
        print json_file
        json_decoded = json.load(json_file)
        x = json_decoded
        start_time = time.clock()
        #print "Start at {}".format(datetime.datetime.now())
        for row in x:
            print row
            l = []
            #print row['id']
            #exit();
if __name__ == "__main__":
    main()
