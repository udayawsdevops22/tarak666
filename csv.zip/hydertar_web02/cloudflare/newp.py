import os
import sys
import csv
import json
import commands
import datetime
import time
import subprocess
import smtplib
import socket
response_json = "cloudflare_res.json"
response_json1 = "cloudflare_res1.json"
API_KEY = "AUHsiustZEn7MjsPvPrhkns-6lw6PFRWdqNZ4ijV"
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())

def get_detailed_test(zone_id):
    print(zone_id)
    print(zone_name)
    cmd = '''
       curl -H \"Authorization: Bearer %s\" -X GET https://api.cloudflare.com/client/v4/zones -H Content-Type:application/json > %d" '''%(API_KEY, response_json1 )
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    stdout=json.loads(stdout)
    #print stdout
    if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1):
        return False
    return stdout
def main():
    f = csv.writer(open("cloudflar_report_full.csv", "wb+"))
    col_names = ['id', 'name', 'start_utc','end_utc', 'recur_every', 'all_tests','raw_tests', 'raw_tags', 'state', 'timezone','follow_dst']
    # Write CSV Header, If you dont need that, remove this line
    f.writerow(col_names)
    count = 0
    for state in ("ACT", "PND"):
        status, output = commands.getstatusoutput("curl -H \"Authorization: Bearer %s\" -X GET https://api.cloudflare.com/client/v4/zones/%s/pagerules -H Content-Type:application/json > %s"%(API_KEY, zone_id response_json)
        )

        json_file = open(response_json,"r")
        print json_file
        json_decoded = json.load(json_file)
        x = json_decoded
        start_time = time.clock()
        #print "Start at {}".format(datetime.datetime.now())
        for row in x:
            print row
            l = []
            #print row['id']
            #exit();
if __name__ == "__main__":
    main()