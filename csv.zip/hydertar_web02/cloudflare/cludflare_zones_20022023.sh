#!/bin/bash

if [ $# -ne 0 ]; then
    echo "usage: $(basename $0)"
    exit 1
fi

BASURL="https://api.cloudflare.com/client/v4/zones"
QUERY="?name=${NAME}"
EMAIL=”tarakaramulu.hyderaboni@effem.com”
AUTHKEY=”f16ccc6b739cc3082e744628ec142d7784053”

zones=$(curl -s -X GET "${BASURL}" \
  -H "X-Auth-Email: ${EMAIL}" \
  -H "X-Auth-Key: ${AUTHKEY}" \
  -H "Content-Type: application/json" | jq '.result[].name' | tr -d '"')

for zone in $zones; do

  echo -n "$zone: "

  id=$(curl -s -X GET "${BASURL}?name=${zone}" \
  -H "X-Auth-Email: ${EMAIL}" \
  -H "X-Auth-Key: ${AUTHKEY}" \
  -H "Content-Type: application/json" | jq '.result[].id')

  echo $id

done

