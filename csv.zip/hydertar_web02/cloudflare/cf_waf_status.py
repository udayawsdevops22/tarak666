import csv
import requests

# Replace <API_KEY> with your API Key
# Replace <API_TOKEN> with your API Token
# Replace <EMAIL> with your Cloudflare account email address
api_key = 'vmAZPnvZVFcjTVJtgzcaGOEG0jHA4sXC-0OzmMFm'
api_token = 'f16ccc6b739cc3082e744628ec142d7784053'
email = 'tarakaramulu.hyderaboni@effem.com'

url = 'https://api.cloudflare.com/client/v4/zones'
headers = {
    'Authorization': f'Bearer {api_key}',
    'Content-Type': 'application/json',
    'X-Auth-Email': email,
    'X-Auth-Key': api_token
}
response = requests.get(url, headers=headers)

zones = response.json()['result']
filename = 'waf_migration_status.csv' # Specify the filename for the CSV file

with open(filename, 'w', newline='') as csvfile:
    fieldnames = ['Zone ID', 'Zone Name', 'WAF Status']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for zone in zones:
        zone_id = zone['id']
        zone_name = zone['name']
        waf_status = zone['settings']['waf']['enabled']
        writer.writerow({'Zone ID': zone_id, 'Zone Name': zone_name, 'WAF Status': waf_status})

print(f'Successfully saved WAF migration status for all zones to {filename}')

