import requests
import csv

# Replace with your Cloudflare API key and email
api_key = "f16ccc6b739cc3082e744628ec142d7784053"
email = "tarakaramulu.hyderaboni@effem.com"

# Define the Cloudflare API endpoint
api_endpoint = "https://api.cloudflare.com/client/v4"

# Get list of all zones (websites)
def get_zones():
    url = f"{api_endpoint}/zones?per_page=600"
    headers = {
        "Content-Type": "application/json",
        "X-Auth-Email": email,
        "X-Auth-Key": api_key
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        zones = response.json()["result"]
        return zones
    else:
        print(f"Failed to get zones. Status code: {response.status_code}")
        return None

# Get WAF rules for a zone
def get_waf_rules(zone_id):
    url = f"{api_endpoint}/zones/{zone_id}/firewall/rules"
    headers = {
        "Content-Type": "application/json",
        "X-Auth-Email": email,
        "X-Auth-Key": api_key
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        rules = response.json()["result"]
        return rules
    else:
        print(f"Failed to get WAF rules for zone {zone_id}. Status code: {response.status_code}")
        return None

# Export WAF rules for all zones to CSV
def export_waf_rules_to_csv(zones):
    with open("waf_rules.csv", "w", newline="") as csvfile:
        fieldnames = ["Zone ID", "Zone_Name","Rule ID", "Description", "action", "priority", "paused"]
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for zone in zones:
            zone_id = zone["id"]
            zone_name = zone["name"]
            rules = get_waf_rules(zone_id)
            if rules:
                for rule in rules:
                    writer.writerow({
                        "Zone ID": zone_id,
						"Zone_Name": zone_name,
                        "Rule ID": rule["id"],
                        "Description": rule["description"],
						"action": rule["action"],
						"paused": rule["paused"]
                    })
                print(f"Exported {len(rules)} WAF rules for zone {zone_name} ({zone_id})")
            else:
                print(f"Failed to export WAF rules for zone {zone_name} ({zone_id})")

# Main function to run the script
def main():
    zones = get_zones()
    if zones:
        export_waf_rules_to_csv(zones)
    else:
        print("Failed to get zones. Please check your API key and email.")

if __name__ == "__main__":
    main()

