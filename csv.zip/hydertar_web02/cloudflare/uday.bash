#/bin/bash
#Step 1: Zone creatation#
Zone_id = ''' curl -X GET "https://api.cloudflare.com/client/v4/zones?name=test1.mars-inc.com" -H "X-Auth-Email: web.tcc.team@effem.com" -H "X-Auth-Key: 49d1601884ee38d4099ab58c55275e609acaa"  -H "Content-Type: application/json"  | jq -r | grep '''"id"''' |  head -n1 |awk '{print $2;}' | sed 's/\,/ \ /g' | sed 's/\"//g' '''