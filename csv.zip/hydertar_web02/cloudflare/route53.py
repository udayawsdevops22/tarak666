import os
import sys
import csv
import json
import datetime
import time
import subprocess
import smtplib
import socket
response_json = "cloudflare_res.json"
API_KEY = "AUHsiustZEn7MjsPvPrhkns-6lw6PFRWdqNZ4ijV"
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())

def main():
    f = csv.writer(open("cloudflare_zones.csv", "w"))

    status, output = subprocess.getstatusoutput(
        "aws route53 list-hosted-zones-by-name > %s"%(response_json)
    )

    json_file = open(response_json,"r")

    json_decoded = json.load(json_file)
   
    col_names = json_decoded.keys()
    # Write CSV Header, If you dont need that, remove this line
    f.writerow(col_names)

    #print(json_decoded)
    print("Start at {}".format(datetime.datetime.now()))
    for row in json_decoded:
        print (row)
        row_item = []

        for col in col_names:
            row_item.append('')
        f.writerow(row_item)
    
if __name__ == "__main__":
    main()
