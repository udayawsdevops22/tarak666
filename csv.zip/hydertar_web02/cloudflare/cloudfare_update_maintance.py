import csv, json
import os, sys
import subprocess
response_json = "cloudflare_res.json"
API_KEY = "AUHsiustZEn7MjsPvPrhkns-6lw6PFRWdqNZ4ijV"


def check_data(Zone_id):
    cmd = '''
    curl -H \"Authorization: Bearer %s\" -X GET "https://api.cloudflare.com/client/v4/zones/%s" '''%(API_KEY, Zone_id)
    print (cmd)
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    stdout=json.loads(stdout)
    print (stdout)
    if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1):
        return False
    return True
    

empty_data_collector = []
with open('Roayalcanin_maintance.csv') as csvfile:

    reader = csv.DictReader(csvfile)
    for request_data in reader:
       if not request_data['source'].strip():           
           empty_data_collector.append(request_data)
           continue
       #if not check_data(request_data['Zone_id']):
           #print ("error: ZoneId (%s) not exist or TestID and URL cannot be updated "%request_data['Zone_id'])
           #continue           
       cmd = '''
       curl -X POST "https://api.cloudflare.com/client/v4/zones/e6615869c476b981d8b054cecd39bfeb/pagerules?direction=asc" -H "X-Auth-Email: web.tcc.team@effem.com" -H "X-Auth-Key: 0ef45099bf2ebdc5ba0eb307c9692a58556c5" -H "Content-Type: application/json" --data '{"targets":[{"target":"url","constraint":{"operator":"matches","value":"%s/*"}}],"actions":[{"id":"forwarding_url","value":{"url":"%s","status_code":302}}],"priority":1,"status":"disabled"}'
       ''' %(request_data['source'],request_data['dist'])
       print(cmd)
       #args = cmd.split()
       #process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
       #stdout, stderr = process.communicate()
       #print (stdout)
       #print (stderr)
print ("Below entrys are missing Zone_ID so skipied {}".format(empty_data_collector))


