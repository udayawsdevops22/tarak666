import csv, json
import os, sys
import subprocess
response_json = "cloudflare_res.json"
API_KEY = "AUHsiustZEn7MjsPvPrhkns-6lw6PFRWdqNZ4ijV"


def check_data(Zone_id):
    cmd = '''
    curl -H \"Authorization: Bearer %s\" -X GET "https://api.cloudflare.com/client/v4/zones/%s" '''%(API_KEY, Zone_id)
    #print (cmd)
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    if not stdout:
        return True
    stdout=json.loads(stdout)
    print (stdout)
    if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1):
        print(Zone_id)
        return False
    return True
    

empty_data_collector = []
with open('WEBSITEa.csv') as csvfile:

    reader = csv.DictReader(csvfile)
    for request_data in reader:
       if not request_data['Zone_id'] .strip():           
           empty_data_collector.append(request_data)
           continue
       if not check_data(request_data['Zone_id']):
           print ("error: ZoneId (%s) not exist or TestID and URL cannot be updated "%request_data['Zone_id'])
           continue           
       cmd = '''
       curl -X POST "https://api.cloudflare.com/client/v4/accounts/e6f519836e79539e099dff199d641d02/firewall/access_rules/rules" -H "X-Auth-Email:web.tcc.team@effem.com" -H "X-Auth-Key:0ef45099bf2ebdc5ba0eb307c9692a58556c5" -H "Content-Type:application/json"   --data '{"mode":"whitelist","configuration":{"target":"ip","value":"%s"},"notes":"appscannerip_one"}' 
       ''' %(request_data['Allow_ip'])
       print(cmd)
       #args = cmd.split()
       #process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
       #stdout, stderr = process.communicate()
       #print (stdout)
       #print (stderr)
print ("Below entrys are missing Zone_ID so skipied {}".format(empty_data_collector))
