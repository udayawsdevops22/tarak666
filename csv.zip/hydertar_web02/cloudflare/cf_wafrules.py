import requests
import csv

# Replace with your Cloudflare API credentials
API_KEY = 'f16ccc6b739cc3082e744628ec142d7784053'
API_EMAIL = 'tarakaramulu.hyderaboni@effem.com'
ZONE_ID = '5b9de91442467c2f6926c5714b444d94'

# Cloudflare API endpoint to get WAF rules
WAF_RULES_ENDPOINT = f'https://api.cloudflare.com/client/v4/zones/{ZONE_ID}/firewall/waf/packages'

# Set up API headers
headers = {
    'X-Auth-Key': API_KEY,
    'X-Auth-Email': API_EMAIL,
    'Content-Type': 'application/json'
}

# Send API request to get WAF rules
response = requests.get(WAF_RULES_ENDPOINT, headers=headers)
if response.status_code == 200:
    waf_rules = response.json()
    # Extract WAF rules data
    print (waf_rules['result'][0]['rules'])
    rules_data = waf_rules['result'][0]['rules']
    # Create a CSV file to export the WAF rules
    with open('waf_rules.csv', 'w', newline='') as csvfile:
        fieldnames = ['id', 'description', 'action', 'filter', 'paused']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        # Write WAF rules data to CSV
        for rule in rules_data:
            writer.writerow({
                'id': rules['id'],
                'description': rules['description'],
                'action': rules['action'],
                'filter': rules['filter'],
                'paused': rules['paused']
            })
    print('WAF rules exported to waf_rules.csv')
else:
    print('Failed to retrieve WAF rules:', response.json())
