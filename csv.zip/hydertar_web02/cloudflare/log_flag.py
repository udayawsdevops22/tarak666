import os
import sys
import csv
import json
import datetime
import time
import requests
import smtplib
import socket
import re

response_json = "cloudflare_res.json"
API_KEY = "AUHsiustZEn7MjsPvPrhkns-6lw6PFRWdqNZ4ijV"
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())


def main():
    f = csv.writer(open("cloudflar_report_log.csv", "w"))

    json_decoded = requests.get('https://api.cloudflare.com/client/v4/zones?per_page=150',
                                headers={
                                    'Authorization': f'Bearer {API_KEY}',
                                    'Content - Type': 'application / json'
                                }).json()

    col_names = ['zone_id', 'zone_name', 'flag']
    # Write CSV Header, If you dont need that, remove this line
    f.writerow(col_names)

    print(f"Total: {len(json_decoded['result'])}")
    print("Start at {}".format(datetime.datetime.now()))
    for row in json_decoded['result']:

        zone_output = requests.get(
            f'https://api.cloudflare.com/client/v4/zones/{row["id"]}/logs/control/retention/flag',
            headers={
                'X-Auth-Key': '9170e69d2ea70069f0063652db9f88e492609',
                'X-Auth-Email': 'fahad.javaid@effem.com',
                'Content - Type': 'application / json'
            }).json()

        print(row["id"], row["name"], zone_output['result']['flag'])
        if isinstance(zone_output['result'], list):
            row_item = [row['id'], row['name'], zone_output['result']['flag']]
            row_item.extend(zone_item.values())
            f.writerow(row_item)
        
    # print "Total done for {} is {}, finished at {}secs".format(state, len(x["data"]), (time.time()-start_time))


if __name__ == "__main__":
    main()