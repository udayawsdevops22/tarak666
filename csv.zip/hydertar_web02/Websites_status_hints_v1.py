#!/usr/bin/python
import os
import re
import subprocess
import datetime
import time
import smtplib
import socket
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())
Mail_subject= 'Website status report on '+ Hostname +' '+ timestamp
#emails=['capacity.reports@mars-inc.com', 'web.tcc.team@effem.com']
emails=['tarakaramulu.hyderaboni@effem.com', 'govardhan.pacharla@effem.com']
To_mail='root@%s'%Hostname

#Email function
def send_mail(send_from, send_to, subject, html, files=[], server="uukmx01.mars-inc.com"):
  #assert type(send_to)==list
  #assert type(files)==list

  msg = MIMEMultipart()
  msg['From'] = send_from
  msg['To'] =  ", ".join(send_to)
  #msg['To'] = send_to
  msg['Date'] = formatdate(localtime=True)
  msg['Subject'] = subject
  #html = html.format(table=tabulate(data, headers="firstrow", tablefmt="html"))
  msg.attach( MIMEText(html,'html'))

  for f in files:
    part = MIMEBase('application', "octet-stream")
    part.set_payload( open(f,"rb").read() )
    Encoders.encode_base64(part)
    part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(f))
    msg.attach(part)

  smtp = smtplib.SMTP(server)
  smtp.sendmail(send_from, send_to, msg.as_string())
  smtp.close()
###########################
bodytext = " "
bodytext1 = " "
bodytext += ("<!DOCTYPE bodytext><bodytext><head><style>table, th, td { border: 1px solid black;}</style></head><body>Hello Team,<br><p>    This is a alert informatation, some of the below websites are not in use or might be migrated to other server, below count is depends on access logs on website which is less the 200 hits in a week. Please verify the logs once again before you reach Brand manager/developer. </p>\n<p>Note:This alert count excluded monitring hits(statuscake). </p><table style='width:100%'> <tr> <th>Website Name</th>    <th>Total count(Last 7days)</th>     <th>Comments</th>  </tr>")
#Command to find all domain in server
os.system(' /usr/sbin/plesk bin site --list > site_list.log')
##Skip the empty lines from file
with open("site_list.log", "r") as f:
    names_list = [line.strip() for line in f if line.strip()]
#find the suspend site from total Domains
for sites in names_list:
    bodytext+="\n"
    #print sites
    vhosts_path = '/home/sites/vhosts/'
    logs ='/logs'
    findlogs = os.popen("/usr/bin/find %s%s%s \( -name 'access_log' -o -name 'access_ssl_log.p*' -o -name 'access_log.p*' \) -mtime -7 | sudo xargs ls > Last7days_logs.log" %(vhosts_path,sites,logs)).read()
    #print findlogs
    with open("Last7days_logs.log", "r" ) as f1:
        names_list1 = [line1.strip() for line1 in f1 if line1.strip()]
        norecent = os.stat("Last7days_logs.log").st_size == 0
	#print norecent
        if norecent == True:
           bodytext += ("<tr> <td>%s</td> <td>N/A</td> <td>No logs generated from 7days</td> </tr>" %sites)
        else:
                        #print "norecent"
			for sites1 in names_list1:
				#bodytext+="\n"
				#print sites
				grepcount = os.popen("zgrep -v '(StatusCake)' %s | wc -l " %(sites1)).read()
				#print ("Day wish count:%s\n%s" %(grepcount,sites1))
				outF = open("countforeachday.log", "a")
				   # write line to output file
				outF.write('%s\n' %grepcount)
				   #outF.write("\n")
				outF.close()
				
			with open('countforeachday.log') as f:
			     fdata=f.read()
			     reObj=re.compile('\d+')
			     mo=reObj.findall(fdata)
			     n=[]
			     for i in mo:n.append(int(i))
			     #print(sum(n))
			     outfile = (sum(n))
			     os.remove('countforeachday.log')
			     os.remove('Last7days_logs.log')
			     #print outfile
			     if outfile <= 200:
			        bodytext +=("<tr> <td>%s</td> <td>%s</td> <td>N/A</td> </tr>" %(sites,outfile))
			     else:
                                #print (" sitename:%s \nTotal Hints:%s" %(sites,outfile))
                                Noresult = "site live"
bodytext += "</table>"
#print bodytext
send_mail(To_mail,emails,Mail_subject,bodytext)
#=========END=========
