#/bin/sh
(sudo plesk bin site --list > list.txt
cat list.txt | while read LINE
do
comm=`sudo plesk bin site -i $LINE | grep OK |wc -l`
#echo $comm
if [ $comm == 1 ]; then
	echo $LINE 
#else
#	echo  $LINE "<<< suspend can be removed >>>"
fi
done) > input.txt
echo 'Content-Type: text/html; charset="us-ascii" ' >> email.html
awk 'BEGIN{ print '<html><head><style>table, th, td {   border: 1px solid black;} .css-serial { counter-reset: serial-number; }.css-serial td:first-child:before { counter-increment: serial-number; content: counter(serial-number);} /style> </head><body><table class="css-serial">  <tr><th>S.no</th><th>Sites</th> </tr>' {print "<tr>";for(i=1;i<=NF;i++)print "for(i=1;i<=NF;i++)print "<td></td><td>" $i"</td>";print "</tr>"} END{print "</table>"}' input.txt >> email.html

echo "</html>" >> email.html
