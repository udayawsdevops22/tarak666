#!/usr/bin/python
# import the MySQLdb and sys modules
import MySQLdb
import os
import csv
import sys
import datetime
import time
import smtplib
import mimetypes
from email.mime.multipart import MIMEMultipart
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.text import MIMEText
now = datetime.datetime.now()
timestamp = now.strftime("%Y%m%d")
reports = open(".reports", "r")  
filename = "%s-webhost_records.csv" % timestamp
# Mysql database connection
f = open("config.txt", "r");
output_dict = {}
for lines in f:
    list1 = lines.replace("\n", "")
    list2 = lines
    connection = MySQLdb.connect (host = list1, user = "reports", passwd = `.reports`  db = "psa" )
    # prepare a cursor object using cursor() method
    cursor = connection.cursor ()
    # execute the SQL query using execute() method.
    cursor.execute ("select name from domains WHERE status = 0;")
    # fetch all of the rows from the query
    #groupids = cursor.fetchall ()
    groupids = [item[0] for item in cursor.fetchall()]
    # execute the SQL query for stop state.
    #cursor.execute ("select name from domains WHERE status != 0;")
    #status = cursor.fetchall ()
    #suspend = str(status).replace("('", "").replace(")", "").replace("(", "").replace(",", "")
    #print suspend
    output1 = str(groupids).replace("('", "").replace(")","\n").replace("'" ,"").replace("," ,"")
    output2 = str(output1)
    output_dict[list1]="%s" %cursor.rowcount
    connection.close()
#def suspend
with open("%s-webhost_records.csv" %timestamp, "wb") as outfile:
   fieldnames = ['Host names', 'Sites Count']
   writer = csv.DictWriter(outfile, fieldnames=fieldnames)
   writer.writeheader()
   for key, value in output_dict.items():
       writer.writerow({'Host names': key, 'Sites Count':value})
emailfrom = "tarakaramulu.hyderaboni@effem.com"
emailto = "stephen.cripps@effem.com,tarakaramulu.hyderaboni@effem.com"
fileToSend = "%s-webhost_records.csv" %timestamp

msg = MIMEMultipart()
msg["From"] = emailfrom
msg["To"] = emailto
msg["Subject"] = "Active Sites and Total site in Linux Servers"
#msg.preamble = "HI Team,'\n' Please find the Attached sheet."
msg["Text"] = "Hi Team,'\n'Please find the Attached sheet."
ctype, encoding = mimetypes.guess_type(fileToSend)
if ctype is None or encoding is not None:
    ctype = "application/octet-stream"

maintype, subtype = ctype.split("/", 1)

if maintype == "text":
    fp = open(fileToSend)
    # Note: we should handle calculating the charset
    attachment = MIMEText(fp.read(), _subtype=subtype)
    fp.close()
elif maintype == "image":
    fp = open(fileToSend, "rb")
    attachment = MIMEImage(fp.read(), _subtype=subtype)
    fp.close()
elif maintype == "audio":
    fp = open(fileToSend, "rb")
    attachment = MIMEAudio(fp.read(), _subtype=subtype)
    fp.close()
else:
    fp = open(fileToSend, "rb")
    attachment = MIMEBase(maintype, subtype)
    attachment.set_payload(fp.read())
    fp.close()
    encoders.encode_base64(attachment)
attachment.add_header("Content-Disposition", "attachment", filename=fileToSend)
msg.attach(MIMEText('Hi Team,\n\n Please find attached sheet for List of active sites count. \n\n\n Thanks & Regards\n Tarak', 'plain'))
msg.attach(attachment)

server = smtplib.SMTP("uukmx01.mars-inc.com")
server.sendmail(emailfrom, emailto, msg.as_string())
server.quit()
