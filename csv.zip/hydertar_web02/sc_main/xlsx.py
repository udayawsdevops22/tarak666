from openpyxl import Workbook
from openpyxl import load_workbook
from openpyxl.styles import PatternFill

wb = load_workbook("sample.xlsx")

ws = wb.active

redFill = PatternFill(start_color='FFFF0000',
               end_color='FFFF0000',
               fill_type='solid')

ws['A2'].fill = redFill

wb.save("sample.xlsx")
