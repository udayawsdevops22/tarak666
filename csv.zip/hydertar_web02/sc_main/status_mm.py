import os
import sys
import csv
import json
import commands
import datetime
import time
import subprocess
import smtplib
import socket
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import encoders

response_json = "status_cake_res.json"
API_KEY = "n8z47hIIErcEcUnXtivj"
USERNAME = "WebCCHosting"
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())
Mail_subject= 'Statuscake active/pending maintenance report -'+ timestamp
Mail_text = 'Hi Team, \n\n This report will help you to cross check or plan the patching and if any other maintenace in statuscake.\n\n Attached "statuscake_maintenance_report_full.csv" file with this mail.\n\n Thanks\n Webcc.'
emails=[sys.argv[1]]
To_mail='Statuscake-webcc@mars-inc.com'


#email function Do Not change
def send_mail(send_from, send_to, subject, text, files=[], server="uukmx01.mars-inc.com"):
  #assert type(send_to)==list
  assert type(files)==list

  msg = MIMEMultipart()
  msg['From'] = send_from
  msg['To'] =  ", ".join(send_to)
  #msg['To'] = send_to
  msg['Date'] = formatdate(localtime=True)
  msg['Subject'] = subject
  msg.attach(MIMEText(text))
  filename='statuscake_maintenance_report_full.csv'
  attachment  =open(filename,'rb')

  part = MIMEBase('application','octet-stream')
  part.set_payload((attachment).read())
  encoders.encode_base64(part)
  part.add_header('Content-Disposition',"attachment; filename= "+filename)

  msg.attach(part)
  smtp = smtplib.SMTP(server)
  smtp.sendmail(send_from, send_to, msg.as_string())
  smtp.close()
#email function end #


def get_detailed_test(id_):
    cmd = '''
    curl -H "API: %s" -H "Username: %s" -X GET https://app.statuscake.com/API/Maintenance/?id=%d'''%(API_KEY, USERNAME, id_)
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    stdout=json.loads(stdout)
    # print stdout
    if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1):
        return False
    return stdout


def main():
    f = csv.writer(open("statuscake_maintenance_report_full.csv", "wb+"))
    col_names = ['id', 'name', 'start_utc','end_utc', 'recur_every', 'all_tests','raw_tests', 'raw_tags', 'state', 'timezone','follow_dst']
    # Write CSV Header, If you dont need that, remove this line
    f.writerow(col_names)
    count = 0
    for state in ("ACT", "PND"):
        status, output = commands.getstatusoutput(
        "curl -H \"API: {}\" -H \"Username: {}\" -X GET https://app.statuscake.com/API/Maintenance/?state={} > {}".format(API_KEY, USERNAME, state, response_json)
        )

        json_file = open(response_json,"r")
        # print json_file
        json_decoded = json.load(json_file)
        x = json_decoded
        start_time = time.clock()
        #print "Start at {}".format(datetime.datetime.now())
        for row in x["data"]:
            #print row
            l = []
            # print row['id']
            # exit();
            for col in col_names:
                detailed_test = get_detailed_test(row['id'])['data']
                # print detailed_test
                if col == "id":
                    row[col] = detailed_test["id"]
                    #print col_value
                if col == "name":
                    row[col] = detailed_test["name"]
                    #print col_value
                if col == "start_utc":
                    row[col] = detailed_test["start_utc"]
                if col == "end_utc":
                    row[col] = detailed_test["end_utc"]
                    #print col_value
                if col == "recur_every":
                    row[col] = detailed_test["recur_every"]
                    #print col_val
                if col == "all_tests":
                    row[col] = detailed_test["all_tests"]
                    #print col_value
                if isinstance(row[col], str):
                    col_value = row[col].encode('ascii', 'ignore').decode('ascii')
                else:
                    col_value = row[col]
                l.append(col_value)
            count = count+1
            f.writerow([unicode(s).encode("utf-8") for s in l])
        #print "Total done for {} is {}, finished at {}secs".format(state, len(x["data"]), (time.time()-start_time))

    os.remove(response_json)
    #os.system('gzip statuscake_maintenance_report_full.csv')
    send_mail(To_mail,emails,Mail_subject,Mail_text)
    #os.remove('statuscake_maintenance_report_full.csv.gz')
if __name__ == "__main__":
    main()
