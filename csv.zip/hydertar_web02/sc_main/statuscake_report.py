import os
import sys 
import csv
import json
import commands
import datetime
import time
import smtplib
import socket
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import encoders
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())
Mail_subject= 'Statuscake Report-'+ timestamp
Mail_text = 'This is status cake report generated using Api'
emails=[sys.argv[1]]
To_mail='root@%s'%Hostname
#email function Do Not change
def send_mail(send_from, send_to, subject, text, files=[], server="uukmx01.mars-inc.com"):
  #assert type(send_to)==list
  assert type(files)==list

  msg = MIMEMultipart()
  msg['From'] = send_from
  msg['To'] =  ", ".join(send_to)
  #msg['To'] = send_to
  msg['Date'] = formatdate(localtime=True)
  msg['Subject'] = subject

  filename='statuscake_report.csv.gz'
  attachment  =open(filename,'rb')

  part = MIMEBase('application','octet-stream')
  part.set_payload((attachment).read())
  encoders.encode_base64(part)
  part.add_header('Content-Disposition',"attachment; filename= "+filename)

  msg.attach(part)
  text = msg.as_string()
  smtp = smtplib.SMTP(server)
  smtp.sendmail(send_from, send_to, msg.as_string())
  smtp.close()
#email function end #


response_json = "status_cake_res.json"

status, output = commands.getstatusoutput("curl -H \"API: n8z47hIIErcEcUnXtivj\" -H \"Username: WebCCHosting\" -X GET https://app.statuscake.com/API/Maintenance/ > %s"%response_json)
#print output

json_file = open(response_json,"r")
json_decoded = json.load(json_file)
x = json_decoded
f = csv.writer(open("statuscake_m_report.csv", "wb+"))
#col_names = ['TestID', 'WebsiteName', 'WebsiteURL', 'CheckRate', 'ContactGroup', 
#'TestTags', 'WebsiteHost', 'Status', 'Uptime','Paused',	'NormalisedResponse', 'TestType', 'Public']
col_names = ['id', 'name', 'end_utc', 'recur_every', 'all_tests','raw_tests', 'raw_tags', 'state', 'timezone','follow_dst']
# Write CSV Header, If you dont need that, remove this line
f.writerow(col_names)
count = 0
for row in x:
    l = []

    try: 
    	for col in col_names:
		col_value = row[col]
		if isinstance(row[col], str):
			col_value = row[col].encode('ascii', 'ignore').decode('ascii') 
		l.append(col_value)
    	count = count+1
      	f.writerow([unicode(s).encode("utf-8") for s in l])
    except Exception as e:
	print l
	print e
	print count
#os.remove(response_json)
#os.system('gzip statuscake_report.csv')
#send_mail(To_mail,emails,Mail_subject,Mail_text)
#os.remove('statuscake_report.csv.gz')
