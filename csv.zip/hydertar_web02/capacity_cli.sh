#/bin/sh
(sudo plesk bin site --list > list.txt
cat list.txt | while read LINE
do
comm=`sudo plesk bin site -i $LINE | grep OK |wc -l`
#echo $comm
if [ $comm == 1 ]; then
	echo $LINE 
else
	echo  $LINE "<<< suspend can be removed >>>"
fi
done) > input.txt
awk 'BEGIN { 
        x = 0;
        print "<table border="1">" 
        print "<tr><th>S.no</th><th>Sites</th></tr>"
    }
    {
        if (NF == 1){
            print "<tr ><td colspan="2">"$i"</td>";
            print "</tr>"
        } else {
            if (x == 0){
                x++;
                print "<tr><td>"$i"</td>"
            } else {
                x = 0;
                print "<td>"$i"</td></tr>"
            }
        }
    }
    END {
        print "</table>"
    }' input.txt > table.html
