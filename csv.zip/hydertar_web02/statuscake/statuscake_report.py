import csv, json
import os, sys
import subprocess
API_KEY = 'n8z47hIIErcEcUnXtivj'
USERNAME = 'WebCCHosting'

            #provide API KEY AND USERNAME
            # Make sure all the column names same as in Field Value 
            # https://www.statuscake.com/api/Tests/Updating%20Inserting%20and%20Deleting%20Tests.md
            # bold field values are required columns.

#fn = sys.argv[1]
def check_report():
    cmd = '''
    curl -H "API: %s" -H "Username: %s" -d  -X GET https://app.statuscake.com/API/Tests '''%(API_KEY, USERNAME)
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    stdout=json.loads(stdout)
    print stdout(TestId)
 #   if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1):
#	return False
#    return True
check_report()
