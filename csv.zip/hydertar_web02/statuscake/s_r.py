import os
import csv
import json
import commands
response_json = "status_cake_res.json"

status, output = commands.getstatusoutput("curl -H \"API: n8z47hIIErcEcUnXtivj\" -H \"Username: WebCCHosting\" -d -X GET https://app.statuscake.com/API/Tests/ > %s"%response_json)
#print output

json_file = open(response_json,"r")
json_decoded = json.load(json_file)
x = json_decoded

f = csv.writer(open("status_cake.csv", "wb+"))
col_names = ['TestID', 'WebsiteName', 'WebsiteURL', 'CheckRate', 'ContactGroup', 
'TestTags', 'WebsiteHost', 'Status', 'Uptime','Paused',	'NormalisedResponse', 'TestType', 'Public']
# Write CSV Header, If you dont need that, remove this line
f.writerow(col_names)
count = 0
for row in x:
    l = []

    try: 
    	for col in col_names:
		col_value = row[col]
		if isinstance(row[col], str):
			col_value = row[col].encode('ascii', 'ignore').decode('ascii') 
		l.append(col_value)
    	count = count+1
      	f.writerow([unicode(s).encode("utf-8") for s in l])
    except Exception as e:
	print l
	print e
	print count
os.remove(response_json)

