import csv
import os, sys
import subprocess
API_KEY = 'n8z47hIIErcEcUnXtivj'
USERNAME = 'WebCCHosting'

            #provide API KEY AND USERNAME
            # Make sure all the column names same as in Field Value 
            # https://www.statuscake.com/api/Tests/Updating%20Inserting%20and%20Deleting%20Tests.md
            # bold field values are required columns.

with open('WEBSITEa.csv') as csvfile:

    reader = csv.DictReader(csvfile)
    for request_data in reader:
       #print request_data['TestTags'] 
       cmd = '''
curl -H "API: %s" -H "Username: %s" -d "TestID=%s&TestTags=%s" -X PUT https://app.statuscake.com/API/Tests/Update'''%(API_KEY,USERNAME,request_data['TestID'],request_data['TestTags'])
       #print cmd
       args = cmd.split()
       process = subprocess.Popen(args, shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
       stdout, stderr = process.communicate()
       #print stdout
       #print stderr
       os.system(cmd)
