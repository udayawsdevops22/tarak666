import csv, json
import os, sys
import subprocess
API_KEY = 'n8z47hIIErcEcUnXtivj'
USERNAME = 'WebCCHosting'

            #provide API KEY AND USERNAME
            # Make sure all the column names same as in Field Value 
            # https://www.statuscake.com/api/Tests/Updating%20Inserting%20and%20Deleting%20Tests.md
            # bold field values are required columns.


def check_data(test_id,web_url):
    cmd = '''
    curl -H "API: %s" -H "Username: %s" -X GET https://app.statuscake.com/API/Tests/Details/?TestID=%d'''%(API_KEY, USERNAME, int(test_id))
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    stdout=json.loads(stdout)
    #print stdout
    if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1) or (stdout['URI'] != web_url):
	return False
    return True


empty_data_collector = []
with open('WEBSITEa.csv') as csvfile:

    reader = csv.DictReader(csvfile)
    for request_data in reader:
       if not request_data['TestID'] .strip():           
           empty_data_collector.append(request_data)
           continue
       if not check_data(request_data['TestID'], request_data['WebsiteURL']):
           print "error: TestId (%s) not exist or TestID and URL cannot be updated "%request_data['TestID']
           continue       
       cmd = '''
       curl -H "API: %s" -H "Username: %s" -d "TestID=%s&TestTags=%s&WebsiteName=%s&WebsiteURL=%s&ContactGroup=%s&Paused=%s&WebsiteHost=%s" -X PUT https://app.statuscake.com/API/Tests/Update'''%(API_KEY,USERNAME,request_data['TestID'],request_data['TestTags'],request_data['WebsiteName'],request_data['WebsiteURL'],request_data['ContactGroup'],request_data['Paused'],request_data['WebsiteHost'])
       print cmd
       #args = cmd.split()
       process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
       stdout, stderr = process.communicate()
       print stdout
       #print stderr
print "Below entrys are missing TESTID so skipied {}".format(empty_data_collector)


