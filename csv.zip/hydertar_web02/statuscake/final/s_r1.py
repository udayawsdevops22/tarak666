import json
import commands
def check_data(test_id):
    cmd = '''
    curl -H "API: %s" -H "Username: %s" -X GET https://app.statuscake.com/API/Tests/Details/?TestID=%d'''%(API_KEY, USERNAME, int(test_id))
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    stdout=json.loads(stdout)
    #print stdout
    if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1):
        return False
    return True


empty_data_collector = []
with open(status_cake.csv) as csvfile:

    reader = csv.DictReader(csvfile)
    for request_data in reader:
       if not request_data['TestID'] .strip():
           empty_data_collector.append(request_data)
           continue
       if not check_data(request_data['TestID']):
           print "error: TestId (%s) not exist or TestID and URL cannot be updated "%request_data['TestID']
           continue
response_json1 = "status_cake1_res.json"
          status, output = commands.getstatusoutput("curl -H \"API: n8z47hIIErcEcUnXtivj\" -H \"Username: WebCCHosting\" -X GET https://app.statuscake.com/API/Tests/Details/?TestID=%s > %s"%i(request_data['TestID'], response_json1)
         print output

#json_file = open(response_json,"r")
#json_decoded = json.load(json_file)
#x = json_decoded

#f = csv.writer(open("status_cake.csv", "wb+"))
#col_names = ['TestID', 'WebsiteName', 'WebsiteURL', 'CheckRate', 'ContactGroup',
#'TestTags', 'WebsiteHost', 'Status', 'Uptime','Paused', 'NormalisedResponse', 'TestType', 'Public']
## Write CSV Header, If you dont need that, remove this line
#f.writerow(col_names)
#count = 0
#for row in x:
#    l = []

#    try:
#        for col in col_names:
#                col_value = row[col]
#                if isinstance(row[col], str):
#                        col_value = row[col].encode('ascii', 'ignore').decode('ascii')
#                l.append(col_value)
#        count = count+1
#        f.writerow([unicode(s).encode("utf-8") for s in l])
#    except Exception as e:
#        print l
#        print e
#        print count
#os.remove(response_json)
#print "Below entrys are missing TESTID so skipied {}".format(empty_data_collector)

