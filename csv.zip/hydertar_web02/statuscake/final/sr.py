import os
import csv
import json
import commands
response_json = "status_cake_res.json"
response_json_full = "status_cake__full_res.json"

status, output = commands.getstatusoutput("curl -H \"API: n8z47hIIErcEcUnXtivj\" -H \"Username: WebCCHosting\" -d -X GET https://app.statuscake.com/API/Tests/ > %s"%response_json)
#print output

json_file = open(response_json,"r")
json_decoded = json.load(json_file)
x = json_decoded

f = csv.writer(open("status_cake1.csv", "wb+"))
col_names = ['TestID']
# Write CSV Header, If you dont need that, remove this line
f.writerow(col_names)
count = 0
for row in x:
    l = []

    try: 
    	for col in col_names:
		col_value = row[col]
		if isinstance(row[col], str):
			col_value = row[col].encode('ascii', 'ignore').decode('ascii') 
		l.append(col_value)
    	count = count+1
      	f.writerow([unicode(s).encode("utf-8") for s in l])
    except Exception as e:
	print l
	print e
	print count
os.remove(response_json)
def check_data(test_id):
    cmd = '''
    curl -H "API: %s" -H "Username: %s" -X GET https://app.statuscake.com/API/Tests/Details/?TestID=%d'''%(API_KEY, USERNAME, int(test_id))
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    stdout=json.loads(stdout)
    #print stdout
    if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1):
        return False
    return True


empty_data_collector = []
with open(status_cake1.csv) as csvfile:

    reader = csv.DictReader(csvfile)
    for request_data in reader:
       if not request_data['TestID'] .strip():
           empty_data_collector.append(request_data)
           continue
       if not check_data(request_data['TestID']):
           print "error: TestId (%s) not exist or TestID and URL cannot be updated "%request_data['TestID']
           continue
       status, output = commands.getstatusoutput("curl -H \"API: n8z47hIIErcEcUnXtivj\" -H \"Username: WebCCHosting\" -X GET https://app.statuscake.com/API/Tests/Details/?TestID=%s > %s" %(request_data['TestID'], response_json_full)
           print output
       json_file1 = open(response_json_full,"r")
       json_decoded1 = json.load(json_file1)
       x1 = json_decoded1

       f1 = csv.writer(open("status_cake_full.csv", "wb+"))
       col_names1 = ['TestID', 'WebsiteName', 'WebsiteURL', 'CheckRate', 'ContactGroup','TestTags', 'WebsiteHost', 'Status', 'Uptime','Paused', 'NormalisedResponse', 'TestType', 'Public']
       # Write CSV Header, If you dont need that, remove this line
       f1.writerow(col_names1)
       count1 = 0
       for row1 in x1:
          l1 = []
       try:
          for col1 in col_names1:
                col_value1 = row1[col1]
                if isinstance(row1[col1], str):
                        col_value1 = row1[col1].encode('ascii', 'ignore').decode('ascii')
                        l1.append(col_value1)
                        count1 = count1+1
                       f1.writerow([unicode(s).encode("utf-8") for s1 in l1])
                      except Exception as e1:
                      print l1
                      print e1
                      print count1
       os.remove(response_json_full)
