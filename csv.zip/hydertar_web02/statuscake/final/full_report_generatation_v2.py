import os
import sys
import csv
import json
import commands
import datetime
import time
import subprocess
import smtplib
import socket
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email.Utils import COMMASPACE, formatdate
from email import encoders
response_json = "status_cake_res.json"
API_KEY = "n8z47hIIErcEcUnXtivj"
USERNAME = "WebCCHosting"
now = datetime.datetime.now()
timestamp = now.strftime("%d-%m-%Y")
Hostname = (socket.gethostname())
Mail_subject= 'Statuscake Report-'+ timestamp
Mail_text = 'This is full status cake report generated using Api'
emails=[sys.argv[1]]
To_mail='root@%s'%Hostname
#email function Do Not change
def send_mail(send_from, send_to, subject, text, files=[], server="uukmx01.mars-inc.com"):
  #assert type(send_to)==list
  assert type(files)==list

  msg = MIMEMultipart()
  msg['From'] = send_from
  msg['To'] =  ", ".join(send_to)
  #msg['To'] = send_to
  msg['Date'] = formatdate(localtime=True)
  msg['Subject'] = subject

  filename='statuscake_report_full.csv.gz'
  attachment  =open(filename,'rb')

  part = MIMEBase('application','octet-stream')
  part.set_payload((attachment).read())
  encoders.encode_base64(part)
  part.add_header('Content-Disposition',"attachment; filename= "+filename)

  msg.attach(part)
  text = msg.as_string()
  smtp = smtplib.SMTP(server)
  smtp.sendmail(send_from, send_to, msg.as_string())
  smtp.close()
#email function end #

status, output = commands.getstatusoutput("curl -H \"API: %s\" -H \"Username: %s\" -d -X GET https://app.statuscake.com/API/Tests/ > %s"%(API_KEY, USERNAME, response_json))
#print output

def get_detailed_test(test_id):
    
    cmd = '''
    curl -H "API: %s" -H "Username: %s" -X GET https://app.statuscake.com/API/Tests/Details/?TestID=%d'''%(API_KEY, USERNAME, int(test_id))
    process = subprocess.Popen(cmd,shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()
    stdout=json.loads(stdout)
    #print stdout
    if ('ErrNo' in stdout.keys() and  stdout['ErrNo']==1):
        return False
    return stdout

def main():
    json_file = open(response_json,"r")
    json_decoded = json.load(json_file)
    x = json_decoded

    f = csv.writer(open("statuscake_report_full.csv", "wb+"))
    col_names = ['TestID', 'WebsiteName', 'WebsiteURL', 'CheckRate', 'ContactGroup', 
    'TestTags', 'WebsiteHost', 'Status', 'Uptime','Paused',    'NormalisedResponse', 'TestType', 'Public',
    'EnableSSLWarning','FollowRedirect','TriggerRate','Confirmation','Timeout']
    # Write CSV Header, If you dont need that, remove this line
    f.writerow(col_names)
    count = 0
    for row in x:
        l = []

        for col in col_names:
            
            if col == "EnableSSLWarning":
                row[col] = get_detailed_test(row['TestID'])["EnableSSLWarning"]
                #print col_value
            if col == "FollowRedirect":
                row[col] = get_detailed_test(row['TestID'])["FollowRedirect"]
                #print col_value
            if col == "TriggerRate":
                row[col] = get_detailed_test(row['TestID'])["TriggerRate"]
                #print col_value
            if col == "Confirmation":
                row[col] = get_detailed_test(row['TestID'])["Confirmation"]
                #print col_value
            if col == "Timeout":
                row[col] = get_detailed_test(row['TestID'])["Timeout"]
                #print col_value
            if isinstance(row[col], str):
                col_value = row[col].encode('ascii', 'ignore').decode('ascii')
            else:
                col_value = row[col]
            l.append(col_value)
        count = count+1
        f.writerow([unicode(s).encode("utf-8") for s in l])
     
    os.remove(response_json)
    os.system('gzip statuscake_report_full.csv')
    send_mail(To_mail,emails,Mail_subject,Mail_text)
    os.remove('statuscake_report_full.csv.gz')
if __name__ == "__main__":
    main()
