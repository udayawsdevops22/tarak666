#!/bin/sh
for LINE in `cat filename.txt`
do
  echo "$LINE"
  nslookup $LINE | grep Address
  #printf "%-4s", $LINE 
  #nslookup $LINE | grep -v nameserver | cut -f 2 | grep name | cut -f 2 -d "=" | sed 's/ //';
done
