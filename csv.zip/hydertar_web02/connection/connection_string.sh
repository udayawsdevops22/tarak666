#!/usr/bin/bash
filename="$1"
#Path = "/home/sites/vhosts"
sites="/home/DPUK-AD.corp/hydertar/connection/sites.txt"
while read -r line; do
    name="$line"
    echo "$name"
    while read -r 
    grep -r "$name" "/home/sites/vhosts/" 
done < "$filename"
