#!/usr/bin/python
# import the MySQLdb and sys modules
import MySQLdb
import os
import csv
import sys
import datetime
import time
import smtplib
import mimetypes
from email.mime.multipart import MIMEMultipart
from email import encoders
from email.message import Message
from email.mime.audio import MIMEAudio
from email.mime.base import MIMEBase
from email.mime.image import MIMEImage
from email.mime.text import MIMEText
now = datetime.datetime.now()
timestamp = now.strftime("%Y%m%d")

filename = "%s-webhost_records.csv" % timestamp
# Mysql database connection
f = open("list.txt", "r");
output_dict = {}
for lines in f:
    list1 = lines.replace("\n", "")
    connection = MySQLdb.connect (host = list1, user = "reports", passwd = "Mars123$", db = "psa" )
    # prepare a cursor object using cursor() method
    cursor = connection.cursor ()
    # execute the SQL query using execute() method.
    cursor.execute ("select name from domains WHERE status = 0;")
    # fetch all of the rows from the query
    #groupids = cursor.fetchall ()
    groupids = [item[0] for item in cursor.fetchall()]
    # execute the SQL query for stop state.
    #cursor.execute ("select name from domains WHERE status != 0;")
    #status = cursor.fetchall ()
    #suspend = str(status).replace("('", "").replace(")", "").replace("(", "").replace(",", "")
    #print suspend
    output1 = str(groupids).replace("('", "").replace(")","\n").replace("'" ,"").replace("," ,"")
    output2 = str(output1)
    output_dict[ list1,cursor.rowcount]
    connection.close()
#def suspend
with open("%s-webhost_records.csv" %timestamp, "wb") as outfile:
   writer = csv.writer(outfile)
   writer.writerow(output_dict.keys())
   writer.writerows(map(None,*output_dict.values()))
emailfrom = "tarakaramulu.hyderaboni@effem.com"
emailto = "tarakaramulu.hyderaboni@effem.com,Chandrasekhar.Pogula@effem.com"
fileToSend = "%s-webhost_records.csv" %timestamp

msg = MIMEMultipart()
msg["From"] = emailfrom
msg["To"] = emailto
msg["Subject"] = "Active Sites and Total site in Linux Servers"
#msg.preamble = "HI Team,'\n' Please find the Attached sheet."
msg["Text"] = "HI Team,'\n' Please find the Attached sheet."
ctype, encoding = mimetypes.guess_type(fileToSend)
if ctype is None or encoding is not None:
    ctype = "application/octet-stream"

maintype, subtype = ctype.split("/", 1)

if maintype == "text":
    fp = open(fileToSend)
    # Note: we should handle calculating the charset
    attachment = MIMEText(fp.read(), _subtype=subtype)
    fp.close()
elif maintype == "image":
    fp = open(fileToSend, "rb")
    attachment = MIMEImage(fp.read(), _subtype=subtype)
    fp.close()
elif maintype == "audio":
    fp = open(fileToSend, "rb")
    attachment = MIMEAudio(fp.read(), _subtype=subtype)
    fp.close()
else:
    fp = open(fileToSend, "rb")
    attachment = MIMEBase(maintype, subtype)
    attachment.set_payload(fp.read())
    fp.close()
    encoders.encode_base64(attachment)
attachment.add_header("Content-Disposition", "attachment", filename=fileToSend)
msg.attach(MIMEText('Hi Team,\n\n Please find attached sheet for List of active sites \n\n\n Thanks & Regards\n Tarak', 'plain'))
msg.attach(attachment)

server = smtplib.SMTP("uukmx01.mars-inc.com")
#server.sendmail(emailfrom, emailto, msg.as_string())
server.quit()
