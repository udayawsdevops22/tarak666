import os
with open('filename.txt') as fp:
    for line in fp:
        #print line
        out = os.system('nslookup %s |grep "Address: " ' %line) 
        print out
