import csv, json
import os, sys
empty_data_collector = []
with open('input1.csv') as csvfile:

    reader = csv.DictReader(csvfile)
    for request_data in reader:
       print ('''"expression"''': request_data['Value'] )
       