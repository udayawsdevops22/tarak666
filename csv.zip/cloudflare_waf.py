#!/usr/bin/env python
import CloudFlare
def main():
    cf = CloudFlare.CloudFlare(
          email="tarakaramulu.hyderaboni@effem.com",
          token="f16ccc6b739cc3082e744628ec142d7784053"
            )
    zones = cf.zones.get(params={'per_page':5})
    for zone in zones:
        zone_name = zone['name']
        zone_id = zone['id']
        settings_ipv6 = cf.zones.settings.ipv6.get(zone_id)
        ipv6_on = settings_ipv6['value']
        print zone_id, ipv6_on, zone_name
    exit(0)
if __name__ == '__main__':
    main()
